﻿namespace Farm
{
	public class Animal
	{
		public string Eat()
		{
			return "eating...";
		}
	}
}

