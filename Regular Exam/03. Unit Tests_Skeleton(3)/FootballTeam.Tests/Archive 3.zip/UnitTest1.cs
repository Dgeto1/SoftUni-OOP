using System;
using NUnit.Framework;

namespace FootballTeam.Tests
{
    public class Tests
    {
        public FootballPlayer player;
        public FootballTeam team;

        private string name = "Ronaldo";
        private int playerNumber = 7;
        private string position = "Forward";

        private string teamName = "Man Utd";
        private int capacity = 15;

        [SetUp]
        public void Setup()
        {
            player = new FootballPlayer(name, playerNumber, position);
            team = new FootballTeam(teamName, capacity);
        }

        [Test]
        public void Test_Constructor()
        {
            Assert.AreEqual(teamName, team.Name);
            Assert.AreEqual(capacity, team.Capacity);
            Assert.AreEqual(0, team.Players.Count);
        }

        [Test]
        public void Test_NameNull()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                team = new FootballTeam(String.Empty, 16);
            });
        }
        [Test]
        public void Test_CapacityLowerThan15()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                team = new FootballTeam("Barcelona", 4);
            });
        }

        [Test]
        public void Test_AddPlayer()
        {
            team.AddNewPlayer(player);
            Assert.AreEqual(1, team.Players.Count);
        }

        [Test]
        public void Test_AddPlayerWhenCapacityFull()
        {
            team = new FootballTeam("Man Utd", 15);
            team.AddNewPlayer(new FootballPlayer("Ronaldo", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Messi", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Di Maria", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Ronaldo", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Messi", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Di Maria", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Ronaldo", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Messi", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Di Maria", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Ronaldo", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Messi", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Di Maria", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Ronaldo", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Messi", 7, "Forward"));
            team.AddNewPlayer(new FootballPlayer("Di Maria", 7, "Forward"));

            string output = team.AddNewPlayer(new FootballPlayer("Ronaldo7", 7, "Forward"));
            Assert.AreEqual("No more positions available!", output);
        }

        [Test]
        public void Test_PickPlayer()
        {
            team.AddNewPlayer(player);
            string pickPlayer = "Ronaldo";
            team.PickPlayer(pickPlayer);
            Assert.AreEqual(player.Name, pickPlayer);
        }

        [Test]
        public void Test_PlayerScore()
        {
            team.AddNewPlayer(player);
            int sg = player.ScoredGoals;
            team.PlayerScore(7);
            Assert.AreEqual(sg+1, player.ScoredGoals);
        }
    }
}